CREATE VIEW view_essay_info AS
  SELECT
    `en`.`essay_id`      AS `essay_id`,
    `en`.`essay_name`    AS `essay_name`,
    `en`.`e_stu_name`    AS `e_stu_name`,
    `en`.`e_stu_no`      AS `e_stu_no`,
    `en`.`essay_route`   AS `essay_route`,
    `en`.`essay_date`    AS `essay_date`,
    `en`.`essay_content` AS `essay_content`,
    `sc`.`sc_id`         AS `sc_id`,
    `sc`.`sc_stu_name`   AS `sc_stu_name`,
    `sc`.`sc_stu_no`     AS `sc_stu_no`,
    `sc`.`sc_tea_name`   AS `sc_tea_name`,
    `sc`.`sc_tea_no`     AS `sc_tea_no`,
    `sc`.`sc_essay_name` AS `sc_essay_name`,
    `sc`.`sc_checked`    AS `sc_checked`,
    `ts`.`stu_no`        AS `stu_no`,
    `ts`.`stu_name`      AS `stu_name`,
    `ts`.`stu_pwd`       AS `stu_pwd`,
    `ts`.`stu_time`      AS `stu_time`,
    `ts`.`stu_checked`   AS `stu_checked`
  FROM ((`final`.`t_essay_info` `en`
    JOIN `final`.`t_select_course_info` `sc`
      ON (((`en`.`essay_name` = `sc`.`sc_essay_name`) AND (`en`.`e_stu_name` = `sc`.`sc_stu_name`) AND
           (`en`.`e_stu_no` = `sc`.`sc_stu_no`)))) JOIN `final`.`t_student_info` `ts`
      ON (((`ts`.`stu_name` = `en`.`e_stu_name`) AND (`ts`.`stu_no` = `en`.`e_stu_no`))))
  WHERE (`sc`.`sc_checked` = '1');

