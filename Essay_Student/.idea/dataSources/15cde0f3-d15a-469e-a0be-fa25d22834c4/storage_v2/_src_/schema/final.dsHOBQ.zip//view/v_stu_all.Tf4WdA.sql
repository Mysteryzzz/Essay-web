CREATE VIEW v_stu_all AS
  SELECT
    `stu`.`stu_no`          AS `stu_no`,
    `stu`.`stu_name`        AS `stu_name`,
    `stu`.`stu_pwd`         AS `stu_pwd`,
    `stu`.`stu_time`        AS `stu_time`,
    `stu`.`stu_checked`     AS `stu_checked`,
    `essay`.`essay_id`      AS `essay_id`,
    `essay`.`essay_name`    AS `essay_name`,
    `essay`.`e_stu_name`    AS `e_stu_name`,
    `essay`.`e_stu_no`      AS `e_stu_no`,
    `essay`.`essay_route`   AS `essay_route`,
    `essay`.`essay_date`    AS `essay_date`,
    `en`.`en_id`            AS `en_id`,
    `en`.`en_tea_name`      AS `en_tea_name`,
    `en`.`en_essay_name`    AS `en_essay_name`,
    `en`.`en_essay_content` AS `en_essay_content`,
    `tea`.`tea_no`          AS `tea_no`,
    `tea`.`tea_name`        AS `tea_name`,
    `tea`.`tea_pwd`         AS `tea_pwd`,
    `sc`.`sc_id`            AS `sc_id`,
    `sc`.`sc_stu_name`      AS `sc_stu_name`,
    `sc`.`sc_stu_no`        AS `sc_stu_no`,
    `sc`.`sc_tea_name`      AS `sc_tea_name`,
    `sc`.`sc_tea_no`        AS `sc_tea_no`,
    `sc`.`sc_essay_name`    AS `sc_essay_name`
  FROM ((((`final`.`t_student_info` `stu`
    JOIN `final`.`t_essay_info` `essay`
      ON (((`stu`.`stu_no` = `essay`.`e_stu_no`) AND (`stu`.`stu_name` = `essay`.`e_stu_name`)))) JOIN
    `final`.`t_essay_name_info` `en` ON ((`essay`.`essay_name` = `en`.`en_essay_name`))) JOIN `final`.`t_tea_info` `tea`
      ON ((`en`.`en_tea_name` = `tea`.`tea_name`))) JOIN `final`.`t_select_course_info` `sc`
      ON (((`tea`.`tea_no` = `sc`.`sc_tea_no`) AND (`tea`.`tea_name` = `sc`.`sc_tea_name`))));

