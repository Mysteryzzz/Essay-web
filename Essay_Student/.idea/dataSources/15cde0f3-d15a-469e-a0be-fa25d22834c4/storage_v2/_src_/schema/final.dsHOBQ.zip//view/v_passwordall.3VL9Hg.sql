CREATE VIEW v_passwordall AS
  SELECT
    `final`.`t_student_info`.`stu_no`   AS `stu_no`,
    `final`.`t_student_info`.`stu_name` AS `stu_name`,
    `final`.`t_student_info`.`stu_pwd`  AS `stu_pwd`,
    `final`.`t_tea_info`.`tea_no`       AS `tea_no`,
    `final`.`t_tea_info`.`tea_name`     AS `tea_name`,
    `final`.`t_tea_info`.`tea_pwd`      AS `tea_pwd`,
    `final`.`t_man_info`.`man_no`       AS `man_no`,
    `final`.`t_man_info`.`man_name`     AS `man_name`,
    `final`.`t_man_info`.`man_pwd`      AS `man_pwd`
  FROM ((`final`.`t_man_info`
    JOIN `final`.`t_tea_info`) JOIN `final`.`t_student_info`);

